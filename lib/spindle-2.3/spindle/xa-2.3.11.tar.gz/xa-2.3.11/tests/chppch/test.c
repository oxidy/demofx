#include "qwerty.h"

~print 5+5
