/* Spindle by lft, http://www.linusakesson.net/software/spindle/
 */

long parseparam(char *str, char **end);
uint8_t ascii_to_petscii(uint8_t ch);
void make_dirart(uint8_t *dirart, char *fname);
