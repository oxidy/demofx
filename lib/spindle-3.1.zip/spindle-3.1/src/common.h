/* Spindle by lft, https://linusakesson.net/software/spindle/
 */

#define SPINDLE_VERSION "Spindle 3.1 by lft, https://linusakesson.net/software/spindle/"
