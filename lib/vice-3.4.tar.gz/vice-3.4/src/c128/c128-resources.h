/*
 * c128-resources.h
 *
 * Written by
 *  Andreas Boose <viceteam@t-online.de>
 *  Marco van den Heuvel <blackystardust68@yahoo.com>
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 *
 */

#ifndef VICE_C128_RESOURCES_H
#define VICE_C128_RESOURCES_H

extern int c128_resources_init(void);
extern void c128_resources_shutdown(void);

extern void c128_resources_update_cia_models(int model);

extern int ieee488_enabled;
extern int reu_enabled;
extern int acia_de_enabled;
extern int acia_d7_enabled;
extern int c128_full_banks;
extern int cia1_model;
extern int cia2_model;

#endif
