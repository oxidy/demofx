/* Spindle by lft, https://linusakesson.net/software/spindle/
 */

// These are taken from stage1.lab:
#define PATCH_OFFSET_1	0x02
#define PATCH_OFFSET_2	0x12
#define PATCH_OFFSET_3	0x9c
#define PATCH_RTS	0x56
